﻿# Getting Started
In the root directory of the project...

1. Prepare project for use: `npm run setup`.
2. Start development server: `npm start`.
3. Push changes to production branch: `npm run push`.

- Express - https://expressjs.com/

# Server Structure

server
  | - apps
        | - base: admin app folder
            | - baseApp.js: admin app
            | - baseRoutes.js: routes for baseApp
        | - etc: same format as base but for each additional app
  | - environment.js: contains constants used through the application
  | - index.html: welcome page
  | - server.js: server constructor file, builds apps when server launches
