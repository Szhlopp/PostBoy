const environment = {};
environment.prod = true;

environment.admin = {};
environment.admin.port = process.env.PORT || "3000";
environment.admin.url = "/admin";

##ENVS##

module.exports = environment;
