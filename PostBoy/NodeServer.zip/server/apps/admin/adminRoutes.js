﻿const express = require("express");
const router = express.Router();
const environment = require("../../environment");

// URL = "/admin"

// All endpoints *must* start with a forward slash "/" or they will be unrecognized
// Endpoints match in a top down order, if the below "catch all" is enabled, no other routes will be accessible.
// router.all("*", (req, res) => {
//   res.status(200);
//   res.send("You have tried to connect to a blocked controller.\nPlease try again later!");
// });

// Endpoint will force the NodeServer to update to latest changes on production branch
router.patch("/patch", (req, res) => {
  var authKey = req.body.authKey;
  console.log(authKey);
  if (!authKey || authKey != "##EDITMEKEY##") {
    res.status(403);
    res.send("Unauthorized Access: Forbidden(403)");
    return;
  }
  require("child_process").exec("cmd /c patch.bat", () => {
    res.status(200);
    res.json({
      "message": "API is now up to date!"
    });
  });
});

router.get("/test", (req, res) => {
  res.status(200);
  res.send("API seems to be working in " + (environment.prod ? "production" : "development") + " mode.");
});

router.all("*", (req, res) => {
  res.status(200);
  res.send("You have tried to connect to a non-existent endpoint.\nPlease verify that you have provided the correct URL and used the correct request TYPE!");
});

module.exports = router;
